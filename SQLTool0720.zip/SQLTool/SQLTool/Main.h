﻿#pragma once
#include "Processor.h"
#include "Track.h"
#include "EpsiSolver.h"
#include "DBSCAN.h"
#include "Cluster.h"
#include <winsock.h>
#include "MiningTools.h"
#include "SampledTrack.h"
#include "TrackSimplify.h"
class Main
{
public:
	Main();
	~Main();
	
};

