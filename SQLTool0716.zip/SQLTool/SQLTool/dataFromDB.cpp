#include "stdafx.h"
class dataFromDB {
	char* BATCHNUMBER;
	double LONGITUDE;
	double LATITUDE;
	char* MEASURETIME;

};