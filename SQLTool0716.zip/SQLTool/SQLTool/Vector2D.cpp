﻿#include "stdafx.h"
#include "Vector2D.h"

