﻿#pragma once
#include "Processor.h"
#include "Track.h"
#include "EpsiSolver.h"
#include "DBSCAN.h"
#include "Cluster.h"
#include <winsock.h>
class Main
{
public:
	Main();
	~Main();
	
};

