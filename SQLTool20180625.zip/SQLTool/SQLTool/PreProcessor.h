﻿#pragma once

#include "Track.h"
#include <mysql.h>
#include <vector>
#include "SqlTool.h"
class PreProcessor
{
	
public:
	SqlTool sqlTool;
	MYSQL_RES *res;
	MYSQL_ROW column;
	PreProcessor();
	~PreProcessor();
	void targetsPreProcession(vector<char*> targets,vector<Track> &HistoryTracks);
	void oneTargetPreProcession(char* target, vector<Track> &HistoryTracks,bool &sameTrack,int &trackID);
	void pointPreprocession(vector<TrackPoint> &details, MYSQL_ROW column, vector<Track>&HistoryTracks,/*HistoryTrack *&curTrack,*/int &trackID,int &lastPosixTime,int &orderNumber,bool &newTrack);
};

