﻿#include "stdafx.h"
#include "PreProcessor.h"
#include "SqlTool.h"


PreProcessor::PreProcessor()
{
}


PreProcessor::~PreProcessor()
{
}
/*
	对入参列表的所有target进行预处理
*/
void PreProcessor::targetsPreProcession(vector<char*> targets, vector<Track> &HistoryTracks) {
	int targetsNum = targets.size();
	bool newTarget = true;
	int trackID = 0;
	for (int counter = 0; counter < targetsNum; counter++) {
		printf("********************************new Target********************************\n");
		oneTargetPreProcession(targets[counter], HistoryTracks, newTarget,trackID);
		newTarget = true;
	}
}

/*
	对特定目标进行预处理
*/
void PreProcessor::oneTargetPreProcession(char* target, vector<Track>&HistoryTracks,bool &newTarget,int &trackID) {

	Track tmp;
	int lastPosixtime = 0;
	int orderNumber = 0;
	sqlTool.operationExcutor(Track::getTargetRecords(target), res);
	mysql_autocommit(&sqlTool.mysql, 0);
	MYSQL_RES *targetRecord = res;
	//HistoryTrack* curTrack;
	vector<TrackPoint> details;
	while (column = mysql_fetch_row(targetRecord)) {		
		pointPreprocession(details,column, HistoryTracks,trackID, lastPosixtime,orderNumber, newTarget);
		newTarget = false;//TODO   改进
	}
	//单目标最后一段轨迹需要专门处理一次
	HistoryTracks.back().trackEndProcession(lastPosixtime, orderNumber, details);
	sqlTool.insertExcutor(HistoryTracks.back().insertSQL().data());
	mysql_commit(&sqlTool.mysql);
}


void PreProcessor::pointPreprocession(vector<TrackPoint>&details,MYSQL_ROW column, vector<Track>&HistoryTracks,/* HistoryTrack *&curTrack,*/int &trackID, int &lastPosixTime,int &orderNumber,bool &newTarget) {
	TrackPoint point = TrackPoint(column[0], column[1], column[2], column[3], column[4], column[5], column[6], column[7], column[8]);
	
	if (point.headOfTrack(lastPosixTime)) {//该点是一段新轨迹
		printf("===============================new track============================\n");
		trackID++;
		if (!newTarget) {//newTarget 已涵盖队列为空的情况，不再另行判断
			Track *lastTrack = &HistoryTracks.back();
			lastTrack->trackEndProcession(lastPosixTime, orderNumber, details);
			sqlTool.insertExcutor(lastTrack->insertSQL().data());	//为了不传类别无关变量res，暂不加入封装
			mysql_commit(&sqlTool.mysql);
			lastPosixTime = 0;			
			orderNumber = 0;			
			details.clear();	
		}
		HistoryTracks.push_back(Track(trackID,point.getTargetID(), point.getSource(),column[9], point.getOperator(), point.getTime()));	//轨迹数组加入新track

	}
	
	//该点本身所需的操作:确定trackID,确定orderNumber，更新lastPosixTime，插入数据库
	point.setTrackID(trackID);
	lastPosixTime = point.getTime();
	point.setOderNumber(++orderNumber);
	details.push_back(point);
	sqlTool.insertExcutor(point.insertSQL().data());	
	printf("                              new point%d                              \n", orderNumber);
}

